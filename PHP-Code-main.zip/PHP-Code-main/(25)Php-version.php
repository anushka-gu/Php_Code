WAP to get php vesion
<br>
<?php

	echo 'Current PHP version: ' . phpversion();
	echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>