WAP to demonstrate string operators in php
<br>
<?php

    $x = "Hello";
    $y = " World!";
    echo $x . $y; // Outputs: Hello World!
    echo "<br>";
    $x .= $y;
    echo $x; // Outputs: Hello World!
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"

?>