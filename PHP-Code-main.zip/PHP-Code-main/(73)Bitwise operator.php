WAP in php for bitwise operator
<br>
<?php
$a = 5;
$b = 3;
echo "a = $a, b = $b <br>";
echo "a & b = " . ($a & $b) . "<br>"; // Bitwise AND
echo "a | b = " . ($a | $b) . "<br>"; // Bitwise OR
echo "a ^ b = " . ($a ^ $b) . "<br>"; // Bitwise XOR
echo "~a = " . (~$a) . "<br>"; // Bitwise NOT
echo "a << 1 = " . ($a << 1) . "<br>"; // Left shift
echo "a >> 1 = " . ($a >> 1) . "<br>"; // Right shift
echo "<br>";
echo "This Program is written by Aaryan Goel 0221BCA163"
?>