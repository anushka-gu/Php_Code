WAP to demonstrate arithmetic operators in php
<br>
<?php

    $x = 10;
    $y = 4;
    
    echo "$x + $y = ". ($x + $y) . "<br>"; // 0utputs: 14
    echo "$x - $y = ". ($x - $y) . "<br>"; // 0utputs: 6
    echo "$x * $y = ". ($x * $y) . "<br>"; // 0utputs: 40
    echo "$x / $y = ". ($x / $y) . "<br>"; // 0utputs: 2.5
    echo "$x % $y = ". ($x % $y) . "<br>"; // 0utputs: 2
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"

?>