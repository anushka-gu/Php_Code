WAP to demonstare while loop in php
<br>
<?php

    $i = 1;
    while ($i <= 10)
    {
        echo $i;  
        echo "\t";
        $i++;
    }
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>