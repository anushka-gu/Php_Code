WAP to demonstare if statement in php
<br>
<?php

    $a = 10;
    $b = 20;
    if($a < $b)
    {
    	echo "Out of $a and $b, $a is smaller.." ;
    } 
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>