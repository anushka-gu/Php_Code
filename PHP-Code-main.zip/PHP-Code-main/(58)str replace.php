WAP in php to demonstrate the use of str_replace()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo str_replace("world", "Dolly", "Hello world!");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>