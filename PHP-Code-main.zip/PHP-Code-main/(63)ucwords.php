WAP in php to demonstrate the use of ucwords()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo ucwords("hello world");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>