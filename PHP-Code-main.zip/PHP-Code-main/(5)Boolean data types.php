WAP to demonstrate booelan data types in php
<br>
<?php

    // Assign the value TRUE to a variable
    $show_error = true;
    var_dump($show_error);
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
    

?>