WAP to demonstrate assignment operators in php
<br>
<?php

    $x = 10;
    echo "$x <br>"; // Outputs: 10
    
    $x = 20;
    $x += 30;
    echo "$x <br>"; // Outputs: 50
    
    $x = 50;
    $x -= 20;
    echo "$x <br>"; // Outputs: 30
    
    $x = 5;
    $x *= 25;
    echo "$x <br>"; // Outputs: 125
    
    $x = 50;
    $x /= 10;
    echo "$x <br>"; // Outputs: 5
    
    $x = 100;
    $x %= 15;
    echo "$x <br>"; // Outputs: 10
    echo "This Program is written by Aaryan Goel 0221BCA163"

?>