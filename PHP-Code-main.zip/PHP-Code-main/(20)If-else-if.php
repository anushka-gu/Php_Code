WAP to demonstare if-else-if statement in php
<br>
<?php

    $a = 45;
    $b = 70;
    
    if ($a > $b)
    {
        echo "$a is bigger than $b";
    } 
    elseif ($a == $b)
    {
        echo "$a is equal to $b";
    }
    else 
    {
        echo "$a is smaller than $b";
    }
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>