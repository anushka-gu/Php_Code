WAP in php to demonstrate the use of ucfirst()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo ucfirst("hello world!");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>