WAP to demonstare do-while loop in php
<br>
<?php

    $i = 1;
    do{
        echo "The number is " . $i . "<br>";
    	$i++;
    }while($i <= 3);
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>