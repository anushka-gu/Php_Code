WAP in php to demonstrate the use of str_word_count()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo str_word_count("Hello world!");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>
