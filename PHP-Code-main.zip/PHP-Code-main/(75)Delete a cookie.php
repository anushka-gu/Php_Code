WAP in php to delete a cookie
<br>
<?php

    // Deleting a cookie
    setcookie("username", "", time()-3600);
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>