WAP in php to demonstrate the use of strpros()
<br>
<?php
echo strpos("Hello world!","world");

echo "<br>";
echo "This Program is written by Aaryan Goel 0221BCA163"
?>