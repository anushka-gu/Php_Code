WAP in php to demonstrate function with parameter
<br>
<html>
<head>
<title>Writing PHP Functions with parameters</title>
</head>
<body>
<?php
function addFunction($num1, $num2) {
    $sum = $num1 + $num2;
    echo "Sum of the two numbers is: $sum";
}

addFunction(10, 20);
echo "<br>";
echo "This Program is written by Aaryan Goel 0221BCA163"
?>
</body>
</html>
