WAP to demonstare constant in php
<br>
<?php

    define("GREETING", "hello world!");
    echo GREETING;
    echo "<br>";
    echo GREETING;
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"

?>