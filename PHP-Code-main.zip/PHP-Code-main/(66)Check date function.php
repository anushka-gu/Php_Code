WAP in php to demonstrate check date function
<br>
<!DOCTYPE html>
<html>
<body>

<?php

    var_dump(checkdate(12,31,-400));echo "<br>";
    var_dump(checkdate(2,29,2003));echo "<br>";
    var_dump(checkdate(2,29,2004));echo "<br>";

?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>