WAP in php to demonstrate the use of substr()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo substr("Hello world",6);
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>
