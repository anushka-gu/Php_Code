WAP in php to open a file
<br>
<html>
<body>
<?php
$file=fopen("Welcome.txt","r")
?>
<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>