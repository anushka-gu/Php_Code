WAP to demonstrate string in php
<br>
<?php

    $my_str = 'World';
    echo "Hello, $my_str!\<br>"; // Displays: Hello World!
    echo 'Hello, $my_str!' . "<br>"; // Displays: Hello, $my_str!
     
    echo 'Hello\tWorld!'; // Displays: Hello\tWorld!
    echo "\<br>Hello\tWorld!<br>"; // Displays: Hello   World!
    echo 'I\'ll be back'; // Displays: I'll be back

    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>