WAP in php for time method
<br>
<?php
$t = time();
echo $t . "<br>";
echo date("Y-m-d", $t);
echo "<br>";
echo "This Program is written by Aaryan Goel 0221BCA163"
?>