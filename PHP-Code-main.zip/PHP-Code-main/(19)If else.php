WAP to demonstare if-else statement in php
<br>
<?php

    $a = 20;
    $b = 15;
    
    if ($a > $b)
    {
       	echo "$a is bigger than $b";
    }
    else
    {
     	echo "$a is NOT bigger than $b";
    }
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>