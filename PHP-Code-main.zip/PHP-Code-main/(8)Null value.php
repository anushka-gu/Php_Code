WAP to demonstrate null value in php
<br>
<?php

    $a = NULL;
    var_dump($a);
     
    $b = "Hello World!";
    $b = NULL;
    var_dump($b);
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"

?>