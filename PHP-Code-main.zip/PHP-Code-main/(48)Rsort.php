WAP in php to demonstrate rsort() an array in descending order 
<br>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Sorting PHP Indexed Array in Descending Order</title>
</head>
<body>

<?php
// Define array
$colors = array("Red", "Green", "Blue", "Yellow");

// Sorting and printing array
rsort($colors);
print_r($colors);
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"

</body>
</html>
