WAP to demonstrate string in php
<br>
<?php

    $a = "Hello world!<br>";
    echo $a;
     
    $b = "Hello world!<br>";
    echo $b;
     
    $c = "Stay here, I'll be back.";
    echo $c;
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"

?>