WAP in php to calculate lenth of a string using built in function
<br>
<!DOCTYPE html>
<html lang="en">
<head>
<title>PHP Calculate String Length</title>
</head>
<body>

<?php
$my_str ='Welcome to Tutorial Republic';

// Calculating and displaying string length
echo strlen($my_str);
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>
