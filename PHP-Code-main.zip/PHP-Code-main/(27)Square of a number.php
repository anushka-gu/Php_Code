WAP to square of a number
<br>
<?php

$number = 5;
$square = $number * $number;

echo "The square of $number is: " . $square . "<br>";
echo "This Program is written by Aaryan Goel 0221BCA163"
?>
