WAP in php for local time function
<br>
<?php
print_r(localtime());
echo "<br><br>";
print_r(localtime(time(), true));
echo "<br>";
echo "This Program is written by Aaryan Goel 0221BCA163"
?>