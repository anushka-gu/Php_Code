WAP in php to demonstrate the use of strupper()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo strtoupper("Hello WORLD!");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>