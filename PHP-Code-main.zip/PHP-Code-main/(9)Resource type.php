WAP to demonstrate resource types in php
<?php

    // Open a file for reading
    $handle = fopen("note.txt", "r");
    var_dump($handle);
    echo "<br>";
    echo "This Program is written by Aaryan Goel 0221BCA163"
?>