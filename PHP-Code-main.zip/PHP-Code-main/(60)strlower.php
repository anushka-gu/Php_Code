WAP in php to demonstrate the use of strlower()
<br>
<!DOCTYPE html>
<html>
<body>

<?php
echo strtolower("Hello WORLD.");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>
