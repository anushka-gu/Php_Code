WAP in php to count number of words in a string 
<br>
<!DOCTYPE html>
</html>
</body>

<?php
echo str_word_count("Hello world!");
?>

<br>
"This Program is written by Aaryan Goel 0221BCA163"
</body>
</html>

